import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/screenshot_item.dart';

class ScreenshotListTile extends StatelessWidget {
  const ScreenshotListTile({
    super.key,
    required this.item,
    required this.selected,
    required this.onTap,
    required this.onFavorite,
  });

  final ScreenshotItem item;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onFavorite;

  @override
  Widget build(BuildContext context) {
    final file = File(item.filePath);

    return Card(
      elevation: selected ? 2 : 0,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: SizedBox(
                  width: 112,
                  height: 72,
                  child: file.existsSync()
                      ? Image.file(file, fit: BoxFit.cover)
                      : const ColoredBox(
                          color: Colors.black12,
                          child: Icon(Icons.broken_image_outlined),
                        ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      item.fileName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      DateFormat('dd.MM.yyyy  HH:mm:ss').format(item.createdAt),
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    const SizedBox(height: 5),
                    Text(
                      item.ocrText.isEmpty
                          ? 'OCR: текст не найден'
                          : item.ocrText.replaceAll('\n', ' '),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: item.favorite
                    ? 'Убрать из избранного'
                    : 'Добавить в избранное',
                onPressed: onFavorite,
                icon: Icon(
                  item.favorite ? Icons.star : Icons.star_border,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
