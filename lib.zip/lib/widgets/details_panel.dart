import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../models/screenshot_item.dart';

class DetailsPanel extends StatelessWidget {
  const DetailsPanel({
    super.key,
    required this.item,
    required this.busy,
    required this.onOpen,
    required this.onShowInFolder,
    required this.onFavorite,
    required this.onRerunOcr,
    required this.onDelete,
  });

  final ScreenshotItem? item;
  final bool busy;
  final VoidCallback onOpen;
  final VoidCallback onShowInFolder;
  final VoidCallback onFavorite;
  final VoidCallback onRerunOcr;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final current = item;

    if (current == null) {
      return const Center(
        child: Text('Выберите скриншот слева'),
      );
    }

    final file = File(current.filePath);

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Expanded(
            flex: 5,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: file.existsSync()
                    ? Image.file(file, fit: BoxFit.contain)
                    : const Center(child: Icon(Icons.broken_image_outlined, size: 64)),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Text(
            current.fileName,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 4),
          Text(
            DateFormat('dd.MM.yyyy  HH:mm:ss').format(current.createdAt),
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              FilledButton.tonalIcon(
                onPressed: busy ? null : onOpen,
                icon: const Icon(Icons.open_in_new),
                label: const Text('Открыть'),
              ),
              FilledButton.tonalIcon(
                onPressed: busy ? null : onShowInFolder,
                icon: const Icon(Icons.folder_open),
                label: const Text('В папке'),
              ),
              FilledButton.tonalIcon(
                onPressed: busy ? null : onFavorite,
                icon: Icon(current.favorite ? Icons.star : Icons.star_border),
                label: Text(current.favorite ? 'Из избранного' : 'В избранное'),
              ),
              FilledButton.tonalIcon(
                onPressed: busy ? null : onRerunOcr,
                icon: const Icon(Icons.document_scanner_outlined),
                label: const Text('OCR снова'),
              ),
              FilledButton.tonalIcon(
                onPressed: busy ? null : onDelete,
                icon: const Icon(Icons.delete_outline),
                label: const Text('Удалить'),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              Text('Распознанный текст', style: Theme.of(context).textTheme.titleSmall),
              const Spacer(),
              IconButton(
                tooltip: 'Копировать текст',
                onPressed: current.ocrText.isEmpty
                    ? null
                    : () {
                        Clipboard.setData(ClipboardData(text: current.ocrText));
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('OCR-текст скопирован')),
                        );
                      },
                icon: const Icon(Icons.copy),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Expanded(
            flex: 3,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Theme.of(context).dividerColor),
                borderRadius: BorderRadius.circular(12),
              ),
              child: SingleChildScrollView(
                child: SelectableText(
                  current.ocrText.isEmpty
                      ? 'Текст на изображении не найден или OCR не смог его распознать.'
                      : current.ocrText,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
