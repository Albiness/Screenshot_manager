import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:open_file/open_file.dart';
import 'package:path/path.dart' as p;
import 'package:window_manager/window_manager.dart';

import '../models/screenshot_item.dart';
import 'region_selector_screen.dart';
import '../services/database_service.dart';
import '../services/hotkey_service.dart';
import '../services/ocr_service.dart';
import '../services/screenshot_service.dart';
import '../widgets/details_panel.dart';
import '../widgets/screenshot_list_tile.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final DatabaseService _databaseService = DatabaseService();
  final ScreenshotService _screenshotService = ScreenshotService();
  final OcrService _ocrService = OcrService();
  final HotkeyService _hotkeyService = HotkeyService();
  final TextEditingController _searchController = TextEditingController();

  List<ScreenshotItem> _items = <ScreenshotItem>[];
  ScreenshotItem? _selected;
  Timer? _searchDebounce;
  bool _favoritesOnly = false;
  bool _loading = true;
  bool _busy = false;
  File? _regionSourceFile;
  bool? _wasWindowMaximized;
  bool? _wasWindowFullScreen;

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
    _loadScreenshots();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        await _hotkeyService.registerCaptureRegion(_captureRegion);
      } catch (error) {
        if (mounted) {
          _showMessage('Не удалось зарегистрировать Ctrl+Shift+S: $error');
        }
      }
    });
  }

  @override
  void dispose() {
    _searchDebounce?.cancel();
    _searchController
      ..removeListener(_onSearchChanged)
      ..dispose();
    unawaited(_hotkeyService.dispose());
    unawaited(_databaseService.close());
    super.dispose();
  }

  void _onSearchChanged() {
    _searchDebounce?.cancel();
    _searchDebounce = Timer(
      const Duration(milliseconds: 220),
      _loadScreenshots,
    );
  }

  Future<void> _loadScreenshots() async {
    if (!mounted) {
      return;
    }

    setState(() => _loading = true);

    try {
      final items = await _databaseService.getScreenshots(
        search: _searchController.text,
        favoritesOnly: _favoritesOnly,
      );

      ScreenshotItem? nextSelected;
      final previousSelectedId = _selected?.id;
      if (previousSelectedId != null) {
        for (final item in items) {
          if (item.id == previousSelectedId) {
            nextSelected = item;
            break;
          }
        }
      }
      nextSelected ??= items.isNotEmpty ? items.first : null;

      if (!mounted) {
        return;
      }

      setState(() {
        _items = items;
        _selected = nextSelected;
      });
    } catch (error) {
      if (mounted) {
        _showMessage('Ошибка чтения базы: $error');
      }
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  Future<void> _captureRegion() async {
    if (_busy || _regionSourceFile != null) return;
    setState(() => _busy = true);

    File? sourceFile;
    try {
      sourceFile = await _screenshotService.captureScreenForRegionSelection();
      if (sourceFile == null) {
        throw StateError(
          _screenshotService.lastError ?? 'Windows не вернула изображение.',
        );
      }
      if (!mounted) return;

      // The screenshot was captured while the application was hidden.
      // Display the selector edge-to-edge, without window decorations or taskbar.
      final wasFullScreen = await windowManager.isFullScreen();
      final wasMaximized = await windowManager.isMaximized();
      _wasWindowFullScreen = wasFullScreen;
      _wasWindowMaximized = wasMaximized;
      if (!wasFullScreen) {
        await windowManager.setFullScreen(true);
      }
      await windowManager.show();
      await windowManager.focus();

      if (!mounted) return;
      setState(() {
        _regionSourceFile = sourceFile;
      });
      sourceFile = null; // The overlay now owns the temp screenshot.
    } catch (error) {
      _showMessage('Ошибка захвата: $error');
    } finally {
      if (sourceFile != null) {
        await _screenshotService.deleteTemporaryFile(sourceFile);
      }
      if (mounted && _regionSourceFile == null) {
        await _restoreWindowSize();
        if (mounted) setState(() => _busy = false);
      }
    }
  }

  Future<void> _confirmRegion(RegionSelection selection) async {
    final sourceFile = _regionSourceFile;
    if (sourceFile == null) return;
    setState(() => _regionSourceFile = null);

    try {
      final output = await _screenshotService.cropAndSave(
        sourceFile: sourceFile,
        selection: selection.rect,
        displayedSize: selection.displayedSize,
      );
      if (output == null) {
        throw StateError(
          _screenshotService.lastError ?? 'Не удалось обрезать изображение.',
        );
      }
      await _indexScreenshot(output);
    } catch (error) {
      _showMessage('Ошибка сохранения области: $error');
    } finally {
      await _screenshotService.deleteTemporaryFile(sourceFile);
      await _restoreWindowSize();
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _cancelRegion() async {
    final sourceFile = _regionSourceFile;
    if (sourceFile == null) return;
    setState(() => _regionSourceFile = null);
    await _screenshotService.deleteTemporaryFile(sourceFile);
    await _restoreWindowSize();
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _restoreWindowSize() async {
    final wasFullScreen = _wasWindowFullScreen;
    final wasMaximized = _wasWindowMaximized;
    _wasWindowFullScreen = null;
    _wasWindowMaximized = null;

    try {
      if (wasFullScreen == false) {
        await windowManager.setFullScreen(false);
        if (wasMaximized == true) {
          await windowManager.maximize();
        } else if (wasMaximized == false) {
          await windowManager.unmaximize();
        }
      }
    } catch (error) {
      _showMessage('Не удалось восстановить размер окна: $error');
    }
  }

  Future<void> _captureScreen() async {
    if (_busy) {
      return;
    }

    setState(() => _busy = true);

    try {
      final file = await _screenshotService.captureScreen();

      if (file == null) {
        if (mounted) {
          _showMessage(
            'Не удалось сделать скриншот экрана: '
            '${_screenshotService.lastError ?? 'неизвестная ошибка'}',
          );
        }
        return;
      }

      await _indexScreenshot(file);
    } catch (error) {
      if (mounted) {
        _showMessage('Не удалось создать скриншот: $error');
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _indexScreenshot(File file) async {
    final ocrResult = await _ocrService.recognize(file);
    final createdAt = DateTime.now();
    final fileName = p.basename(file.path);
    final searchText = '$fileName\n${ocrResult.text}'.toLowerCase();

    final item = ScreenshotItem(
      filePath: file.path,
      fileName: fileName,
      createdAt: createdAt,
      ocrText: ocrResult.text,
      searchText: searchText,
    );

    final id = await _databaseService.insertScreenshot(item);
    _selected = item.copyWith(id: id);
    await _loadScreenshots();

    if (!mounted) {
      return;
    }

    if (ocrResult.succeeded) {
      _showMessage(
        ocrResult.text.isEmpty
            ? 'Скриншот сохранён. OCR не нашёл текста.'
            : 'Скриншот сохранён и проиндексирован.',
      );
    } else {
      _showMessage(
        'Скриншот сохранён, но OCR не сработал: ${ocrResult.error}',
      );
    }
  }

  Future<void> _toggleFavorite(ScreenshotItem item) async {
    final id = item.id;
    if (id == null) {
      return;
    }

    await _databaseService.setFavorite(id, !item.favorite);
    _selected = item.copyWith(favorite: !item.favorite);
    await _loadScreenshots();
  }

  Future<void> _rerunOcr(ScreenshotItem item) async {
    final id = item.id;
    final file = File(item.filePath);

    if (id == null || !await file.exists()) {
      _showMessage('Файл скриншота не найден.');
      return;
    }

    setState(() => _busy = true);

    try {
      final result = await _ocrService.recognize(file);
      if (!result.succeeded) {
        _showMessage('OCR не сработал: ${result.error}');
        return;
      }

      await _databaseService.updateOcr(
        id: id,
        fileName: item.fileName,
        ocrText: result.text,
      );
      _selected = item.copyWith(
        ocrText: result.text,
        searchText: '${item.fileName}\n${result.text}'.toLowerCase(),
      );
      await _loadScreenshots();
      _showMessage('OCR обновлён.');
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _deleteScreenshot(ScreenshotItem item) async {
    final id = item.id;
    if (id == null) {
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Удалить скриншот?'),
        content: const Text('Файл и запись в локальной базе будут удалены.'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );

    if (confirmed != true) {
      return;
    }

    final file = File(item.filePath);
    if (await file.exists()) {
      await file.delete();
    }
    await _databaseService.deleteScreenshot(id);
    _selected = null;
    await _loadScreenshots();
  }

  Future<void> _openScreenshot(ScreenshotItem item) async {
    if (!await File(item.filePath).exists()) {
      _showMessage('Файл не найден.');
      return;
    }
    await OpenFile.open(item.filePath);
  }

  Future<void> _showInFolder(ScreenshotItem item) async {
    if (!Platform.isWindows) {
      return;
    }

    if (!await File(item.filePath).exists()) {
      _showMessage('Файл не найден.');
      return;
    }

    await Process.run(
      'explorer.exe',
      <String>['/select,', item.filePath],
      runInShell: true,
    );
  }

  void _showMessage(String text) {
    if (!mounted) {
      return;
    }
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _regionSourceFile == null
          ? AppBar(
              title: const Text('Smart Screenshot Manager'),
              actions: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: Center(
                    child: Text(
                      'Ctrl + Shift + S',
                      style: Theme.of(context).textTheme.labelMedium,
                    ),
                  ),
                ),
              ],
            )
          : null,
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: TextField(
                        controller: _searchController,
                        decoration: InputDecoration(
                          hintText: 'Поиск по имени файла и тексту внутри скриншота',
                          prefixIcon: const Icon(Icons.search),
                          suffixIcon: _searchController.text.isEmpty
                              ? null
                              : IconButton(
                                  tooltip: 'Очистить поиск',
                                  onPressed: _searchController.clear,
                                  icon: const Icon(Icons.close),
                                ),
                          border: const OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    FilterChip(
                      selected: _favoritesOnly,
                      label: const Text('Избранное'),
                      avatar: const Icon(Icons.star_outline, size: 18),
                      onSelected: (value) {
                        setState(() => _favoritesOnly = value);
                        _loadScreenshots();
                      },
                    ),
                    const SizedBox(width: 10),
                    FilledButton.icon(
                      onPressed: _busy ? null : _captureRegion,
                      icon: const Icon(Icons.crop_free),
                      label: const Text('Область'),
                    ),
                    const SizedBox(width: 8),
                    FilledButton.tonalIcon(
                      onPressed: _busy ? null : _captureScreen,
                      icon: const Icon(Icons.desktop_windows_outlined),
                      label: const Text('Весь экран'),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final showDetails = constraints.maxWidth >= 900;

                    final listPanel = SizedBox(
                      width: showDetails ? constraints.maxWidth * 0.47 : constraints.maxWidth,
                      child: _buildListPanel(),
                    );

                    if (!showDetails) {
                      return listPanel;
                    }

                    return Row(
                      children: <Widget>[
                        listPanel,
                        const VerticalDivider(width: 1),
                        Expanded(
                          child: DetailsPanel(
                            item: _selected,
                            busy: _busy,
                            onOpen: () {
                              final selected = _selected;
                              if (selected != null) {
                                _openScreenshot(selected);
                              }
                            },
                            onShowInFolder: () {
                              final selected = _selected;
                              if (selected != null) {
                                _showInFolder(selected);
                              }
                            },
                            onFavorite: () {
                              final selected = _selected;
                              if (selected != null) {
                                _toggleFavorite(selected);
                              }
                            },
                            onRerunOcr: () {
                              final selected = _selected;
                              if (selected != null) {
                                _rerunOcr(selected);
                              }
                            },
                            onDelete: () {
                              final selected = _selected;
                              if (selected != null) {
                                _deleteScreenshot(selected);
                              }
                            },
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
          if (_regionSourceFile != null)
            Positioned.fill(
              child: RegionSelectorScreen(
                imageFile: _regionSourceFile!,
                onConfirm: (selection) {
                  unawaited(_confirmRegion(selection));
                },
                onCancel: () {
                  unawaited(_cancelRegion());
                },
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildListPanel() {
    if (_loading && _items.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_items.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const Icon(Icons.screenshot_monitor_outlined, size: 72),
              const SizedBox(height: 16),
              Text(
                _searchController.text.trim().isEmpty
                    ? 'Скриншотов пока нет'
                    : 'Ничего не найдено',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              const Text(
                'Нажмите «Область» или Ctrl+Shift+S. После сохранения OCR выполнится локально.',
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }

    return Stack(
      children: <Widget>[
        ListView.builder(
          padding: const EdgeInsets.all(10),
          itemCount: _items.length,
          itemBuilder: (context, index) {
            final item = _items[index];
            return ScreenshotListTile(
              item: item,
              selected: item.id == _selected?.id,
              onTap: () => setState(() => _selected = item),
              onFavorite: () => _toggleFavorite(item),
            );
          },
        ),
        if (_loading)
          const Positioned(
            top: 8,
            right: 8,
            child: SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          ),
      ],
    );
  }
}
