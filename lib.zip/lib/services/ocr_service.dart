import 'dart:io';

import 'package:platform_ocr/platform_ocr.dart';

class OcrReadResult {
  const OcrReadResult({required this.text, this.error});

  final String text;
  final String? error;

  bool get succeeded => error == null;
}

class OcrService {
  final PlatformOcr _ocr = PlatformOcr();

  Future<OcrReadResult> recognize(File imageFile) async {
    try {
      final result = await _ocr.recognizeText(OcrSource.file(imageFile));
      return OcrReadResult(text: result.text.trim());
    } catch (error) {
      return OcrReadResult(
        text: '',
        error: error.toString(),
      );
    }
  }
}
