import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:window_manager/window_manager.dart';

/// Windows-only screenshot capture that does NOT use screen_capturer.
/// The capture is made by Windows PowerShell 5.1 + System.Drawing.
/// No network, AI, or third-party screenshot picker is involved.
class ScreenshotService {
  String? lastError;

  Future<Directory> getScreenshotDirectory() async {
    final documentsDirectory = await getApplicationDocumentsDirectory();
    final directory = Directory(
      p.join(documentsDirectory.path, 'SmartScreenshotManager', 'screenshots'),
    );
    await directory.create(recursive: true);
    return directory;
  }

  Future<File?> captureScreen() async {
    final output = await _newScreenshotFile();
    return await _takeScreenshot(output) ? output : null;
  }

  /// The source screenshot is temporary. The selector crops it after confirmation.
  Future<File?> captureScreenForRegionSelection() async {
    final directory = await getTemporaryDirectory();
    final stamp = DateFormat('yyyyMMdd_HHmmss_SSS').format(DateTime.now());
    final output = File(p.join(directory.path, 'ssm_source_$stamp.png'));
    return await _takeScreenshot(output) ? output : null;
  }

  Future<bool> _takeScreenshot(File output) async {
    lastError = null;

    if (!Platform.isWindows) {
      lastError = 'Эта версия захвата поддерживает только Windows.';
      return false;
    }

    try {
      await output.parent.create(recursive: true);

      // The application's own window must not appear in the screenshot.
      await windowManager.hide();
      await Future<void>.delayed(const Duration(milliseconds: 450));

      // Avoid interpolating an unescaped path into PowerShell commands.
      final escapedPath = output.path.replaceAll("'", "''");
      final script = '''
\$ErrorActionPreference = 'Stop'
# Request physical pixel coordinates before Windows.Forms creates its screen cache.
# At 125%-150% display scaling, an unaware PowerShell process could otherwise
# report virtualized dimensions and capture only part of the actual desktop.
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class ScreenshotDpi {
  [DllImport("user32.dll")]
  public static extern bool SetProcessDPIAware();
}
'@
[void][ScreenshotDpi]::SetProcessDPIAware()
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
\$screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
if (\$screen.Width -lt 1 -or \$screen.Height -lt 1) {
  throw 'Primary screen size is invalid.'
}
\$bitmap = [System.Drawing.Bitmap]::new(\$screen.Width, \$screen.Height)
\$graphics = [System.Drawing.Graphics]::FromImage(\$bitmap)
try {
  \$graphics.CopyFromScreen(\$screen.Left, \$screen.Top, 0, 0, \$bitmap.Size)
  \$bitmap.Save('$escapedPath', [System.Drawing.Imaging.ImageFormat]::Png)
} finally {
  \$graphics.Dispose()
  \$bitmap.Dispose()
}
''';

      // -EncodedCommand consumes UTF-16LE, including paths with Cyrillic characters.
      final codeUnits = script.codeUnits;
      final bytes = Uint8List(codeUnits.length * 2);
      for (var i = 0; i < codeUnits.length; i++) {
        bytes[i * 2] = codeUnits[i] & 0xff;
        bytes[i * 2 + 1] = codeUnits[i] >> 8;
      }

      final result = await Process.run(
        'powershell.exe',
        <String>[
          '-NoLogo',
          '-NoProfile',
          '-NonInteractive',
          '-STA',
          '-EncodedCommand',
          base64Encode(bytes),
        ],
        runInShell: false,
      );

      if (result.exitCode != 0) {
        final detail = result.stderr.toString().trim();
        throw StateError(
          'Windows screenshot failed (exit ${result.exitCode}): '
          '${detail.isEmpty ? result.stdout : detail}',
        );
      }
      if (!await output.exists() || await output.length() == 0) {
        throw StateError('Windows did not create the PNG file.');
      }
      return true;
    } catch (error, stackTrace) {
      lastError = error.toString();
      debugPrint('Screenshot capture failed: $error\n$stackTrace');
      return false;
    } finally {
      // Restore the window even when the capture executable fails.
      try {
        await windowManager.show();
        await windowManager.focus();
      } catch (error) {
        debugPrint('Failed to restore application window: $error');
      }
    }
  }

  Future<File?> cropAndSave({
    required File sourceFile,
    required Rect selection,
    required Size displayedSize,
  }) async {
    lastError = null;
    if (!await sourceFile.exists() ||
        displayedSize.width <= 0 ||
        displayedSize.height <= 0 ||
        selection.width < 2 ||
        selection.height < 2) {
      lastError = 'Некорректный размер области или исходного изображения.';
      return null;
    }

    try {
      final sourceImage = img.decodeImage(await sourceFile.readAsBytes());
      if (sourceImage == null) {
        throw StateError('Could not decode screenshot PNG.');
      }

      final scaleX = sourceImage.width / displayedSize.width;
      final scaleY = sourceImage.height / displayedSize.height;
      final left = selection.left.clamp(0.0, displayedSize.width);
      final top = selection.top.clamp(0.0, displayedSize.height);
      final right = selection.right.clamp(0.0, displayedSize.width);
      final bottom = selection.bottom.clamp(0.0, displayedSize.height);

      var x = (left * scaleX).floor();
      var y = (top * scaleY).floor();
      var width = ((right - left) * scaleX).round();
      var height = ((bottom - top) * scaleY).round();

      x = x.clamp(0, math.max(0, sourceImage.width - 1));
      y = y.clamp(0, math.max(0, sourceImage.height - 1));
      width = width.clamp(1, sourceImage.width - x);
      height = height.clamp(1, sourceImage.height - y);

      final output = await _newScreenshotFile();
      final cropped = img.copyCrop(
        sourceImage,
        x: x,
        y: y,
        width: width,
        height: height,
      );
      await output.writeAsBytes(img.encodePng(cropped), flush: true);
      return output;
    } catch (error, stackTrace) {
      lastError = error.toString();
      debugPrint('Screenshot cropping failed: $error\n$stackTrace');
      return null;
    }
  }

  Future<void> deleteTemporaryFile(File? file) async {
    if (file == null) return;
    try {
      if (await file.exists()) await file.delete();
    } catch (error) {
      debugPrint('Temporary screenshot cleanup failed: $error');
    }
  }

  Future<File> _newScreenshotFile() async {
    final directory = await getScreenshotDirectory();
    final stamp = DateFormat('yyyyMMdd_HHmmss_SSS').format(DateTime.now());
    return File(p.join(directory.path, 'screenshot_$stamp.png'));
  }
}
