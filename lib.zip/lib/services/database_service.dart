import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import '../models/screenshot_item.dart';

class DatabaseService {
  Database? _database;

  Future<Database> get database async {
    final existing = _database;
    if (existing != null) {
      return existing;
    }

    final opened = await _openDatabase();
    _database = opened;
    return opened;
  }

  Future<Database> _openDatabase() async {
    sqfliteFfiInit();

    final supportDirectory = await getApplicationSupportDirectory();
    final databaseDirectory = Directory(
      p.join(supportDirectory.path, 'SmartScreenshotManager', 'database'),
    );
    await databaseDirectory.create(recursive: true);

    final databasePath = p.join(databaseDirectory.path, 'screenshots.db');

    return databaseFactoryFfi.openDatabase(
      databasePath,
      options: OpenDatabaseOptions(
        version: 1,
        onCreate: (db, version) async {
          await db.execute('''
            CREATE TABLE screenshots (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              file_path TEXT NOT NULL UNIQUE,
              file_name TEXT NOT NULL,
              created_at INTEGER NOT NULL,
              ocr_text TEXT NOT NULL DEFAULT '',
              search_text TEXT NOT NULL DEFAULT '',
              favorite INTEGER NOT NULL DEFAULT 0
            )
          ''');

          await db.execute(
            'CREATE INDEX idx_screenshots_created_at '
            'ON screenshots(created_at DESC)',
          );
          await db.execute(
            'CREATE INDEX idx_screenshots_favorite '
            'ON screenshots(favorite)',
          );
        },
      ),
    );
  }

  Future<int> insertScreenshot(ScreenshotItem item) async {
    final db = await database;
    return db.insert('screenshots', item.toMap());
  }

  Future<List<ScreenshotItem>> getScreenshots({
    String search = '',
    bool favoritesOnly = false,
  }) async {
    final db = await database;
    final normalizedSearch = search.trim().toLowerCase();

    String? where;
    final whereArgs = <Object?>[];

    if (favoritesOnly && normalizedSearch.isNotEmpty) {
      where = 'favorite = 1 AND search_text LIKE ?';
      whereArgs.add('%$normalizedSearch%');
    } else if (favoritesOnly) {
      where = 'favorite = 1';
    } else if (normalizedSearch.isNotEmpty) {
      where = 'search_text LIKE ?';
      whereArgs.add('%$normalizedSearch%');
    }

    final rows = await db.query(
      'screenshots',
      where: where,
      whereArgs: whereArgs.isEmpty ? null : whereArgs,
      orderBy: 'created_at DESC',
    );

    return rows.map(ScreenshotItem.fromMap).toList(growable: false);
  }

  Future<void> setFavorite(int id, bool favorite) async {
    final db = await database;
    await db.update(
      'screenshots',
      <String, Object?>{'favorite': favorite ? 1 : 0},
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
  }

  Future<void> updateOcr({
    required int id,
    required String fileName,
    required String ocrText,
  }) async {
    final db = await database;
    final searchText = '$fileName\n$ocrText'.toLowerCase();

    await db.update(
      'screenshots',
      <String, Object?>{
        'ocr_text': ocrText,
        'search_text': searchText,
      },
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
  }

  Future<void> deleteScreenshot(int id) async {
    final db = await database;
    await db.delete(
      'screenshots',
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
  }

  Future<void> close() async {
    await _database?.close();
    _database = null;
  }
}
