import 'dart:async';

import 'package:flutter/services.dart';
import 'package:hotkey_manager/hotkey_manager.dart';

class HotkeyService {
  HotKey? _captureRegionHotKey;

  Future<void> registerCaptureRegion(Future<void> Function() onPressed) async {
    await hotKeyManager.unregisterAll();

    final hotKey = HotKey(
      key: PhysicalKeyboardKey.keyS,
      modifiers: <HotKeyModifier>[
        HotKeyModifier.control,
        HotKeyModifier.shift,
      ],
      scope: HotKeyScope.system,
    );

    _captureRegionHotKey = hotKey;

    await hotKeyManager.register(
      hotKey,
      keyDownHandler: (_) {
        unawaited(onPressed());
      },
    );
  }

  Future<void> dispose() async {
    final hotKey = _captureRegionHotKey;
    if (hotKey != null) {
      await hotKeyManager.unregister(hotKey);
    }
  }
}
